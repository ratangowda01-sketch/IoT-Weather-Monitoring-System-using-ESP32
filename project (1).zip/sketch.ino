#include "DHT.h"
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define DHTPIN 15
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

void setup() {

Serial.begin(115200);

dht.begin();

Wire.begin(21,22);

display.begin(SSD1306_SWITCHCAPVCC, 0x3C);

display.clearDisplay();

}

void loop() {

float temperature = dht.readTemperature();
float humidity = dht.readHumidity();

Serial.print("Temperature: ");
Serial.println(temperature);

Serial.print("Humidity: ");
Serial.println(humidity);

display.clearDisplay();

display.setTextSize(1);
display.setTextColor(WHITE);

display.setCursor(0,10);
display.print("Temp: ");
display.print(temperature);
display.println(" C");

display.setCursor(0,30);
display.print("Humidity: ");
display.print(humidity);
display.println(" %");

display.display();

delay(2000);

}